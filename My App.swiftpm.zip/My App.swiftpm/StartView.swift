import SwiftUI

struct StartView: View {
    @Binding var hasStarted: Bool
    @State private var pageIndex: Int = 0
    
    var body: some View {
        VStack(spacing: 28) {
            Spacer()
            
            VStack(spacing: 14) {
                Text("Accessibility Lens")
                    .font(.system(.largeTitle, design: .rounded).bold())
                
                Text(bodyText)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
            }
            
            Spacer()
            
            Text("Tap to continue")
                .font(.headline)
                .foregroundStyle(.secondary)
                .padding(.bottom, 12)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            withAnimation(.spring()) {
                if pageIndex == 0 {
                    pageIndex = 1
                } else {
                    hasStarted = true
                }
            }
        }
    }
    
    private var bodyText: String {
        if pageIndex == 0 {
            return "Have you ever thought about the troubles disabled people go through each day?"
        } else {
            return "You will now try to navigate going to class but in the lens of being disabled"
        }
    }
}
