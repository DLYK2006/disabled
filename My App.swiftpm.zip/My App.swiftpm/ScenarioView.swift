import SwiftUI

struct ScenarioView: View {
    @EnvironmentObject var model: AppModel
    
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Color(.systemBackground).ignoresSafeArea()
                
                if model.showEducationalInterstitial {
                    interstitialView
                } else {
                    VStack(spacing: 14) {
                        header
                        stageBody
                    }
                    .padding()
                }
                
                if let feedback = model.stageFeedback {
                    feedbackOverlay(feedback)
                }
            }
            .onAppear {
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.beginLensSessionIfNeeded()
            }
            .onChange(of: geo.size) { _, _ in
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.configureCurrentStage()
            }
            .onChange(of: model.currentStepIndex) { _, _ in
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.configureCurrentStage()
            }
            .onReceive(timer) { _ in
                model.updateMotorTimeout()
            }
        }
    }
    
    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label(model.currentScenario.name, systemImage: "book.fill")
                    .font(.system(.title2, design: .rounded).weight(.bold))
                Spacer()
                if model.isCurrentLensCompleted {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.title3)
                        .foregroundStyle(.green)
                        .accessibilityLabel("Lens completed")
                }
            }
            
            if model.shouldShowProgress {
                ProgressView(value: model.progress)
                    .tint(.blue)
                Text(model.stepLabel)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            
            Text(model.currentScenario.steps[model.currentStepIndex].title)
                .font(.system(.headline, design: .rounded))
            Text(model.currentScenario.steps[model.currentStepIndex].description)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: .black.opacity(0.2), radius: 6, x: 0, y: 3)
    }
    
    @ViewBuilder
    private var stageBody: some View {
        switch model.currentLens {
        case .blindness:
            blindnessStage
        case .motorImpairment:
            motorStage
        case .neurodiversity:
            neurodiversityStage
        case .none:
            EmptyView()
        }
    }
    
    private var blindnessStage: some View {
        GeometryReader { localGeo in
            ZStack {
                Button {
                    model.triggerBlindnessAction()
                } label: {
                    Text(model.currentScenario.steps[model.currentStepIndex].actionLabelOn)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(height: model.supportsEnabled ? 42 : 34)
                        .frame(minWidth: model.supportsEnabled ? 140 : 110)
                        .background(model.isButtonRevealed ? Color.green : Color.clear, in: Capsule())
                }
                .position(model.realButtonPosition)
                .disabled(!model.isButtonRevealed)
                .opacity(model.isButtonRevealed ? 1 : 0.01)
                .shadow(
                    color: .green.opacity(
                        model.isButtonRevealed
                        ? (model.supportsEnabled ? (0.25 + (0.35 * model.blindnessPulseOpacity)) : 0.65)
                        : 0
                    ),
                    radius: model.supportsEnabled ? 6 : 10,
                    x: 0,
                    y: 0
                )
                
                if !model.supportsEnabled {
                    ForEach(Array(model.blindnessDecoyPositions.enumerated()), id: \.offset) { _, decoyPosition in
                        Button {
                            // distraction only
                        } label: {
                            Capsule()
                                .fill(Color.red)
                                .frame(width: 76, height: 28)
                        }
                        .position(decoyPosition)
                        .buttonStyle(.plain)
                    }
                }
                
                if !model.isButtonRevealed {
                    Rectangle()
                        .fill(Color.black.opacity(model.supportsEnabled ? 0.92 : 1.0))
                        .mask(
                            ZStack {
                                Rectangle().fill(Color.white)
                                if let flashlightLocation = model.flashlightPoint {
                                    Circle()
                                        .fill(
                                            RadialGradient(
                                                colors: [
                                                    .black,
                                                    .black.opacity(model.supportsEnabled ? 0.98 : 0.45),
                                                    .clear
                                                ],
                                                center: .center,
                                                startRadius: 1,
                                                endRadius: model.flashlightRadius
                                            )
                                        )
                                        .frame(width: model.flashlightRadius * 2, height: model.flashlightRadius * 2)
                                        .position(flashlightLocation)
                                        .blur(radius: model.supportsEnabled ? 0.25 : 1.2)
                                        .blendMode(.destinationOut)
                                }
                            }
                                .compositingGroup()
                        )
                        .allowsHitTesting(false)
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged { value in
                        if model.flashlightPoint == nil {
                            model.beginBlindnessFlashlight(at: value.location)
                        } else {
                            model.moveBlindnessFlashlight(to: value.location)
                        }
                    }
                    .onEnded { _ in
                        model.endBlindnessFlashlight()
                    }
            )
            .onAppear {
                model.setupStage(in: localGeo.size)
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { _, newSize in
                model.setupStage(in: newSize)
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    
    private var motorStage: some View {
        GeometryReader { localGeo in
            ZStack {
                Color(.secondarySystemBackground)
                Button {
                    if model.supportsEnabled {
                        model.triggerMotorTap()
                    }
                } label: {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(.blue)
                        .frame(width: model.supportsEnabled ? 220 : 15, height: model.supportsEnabled ? 60 : 15)
                        .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
                }
                .position(model.motorButtonPosition)
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.6)
                        .onEnded { _ in
                            if !model.supportsEnabled {
                                model.triggerMotorOffLongPress()
                            }
                        }
                )
                .simultaneousGesture(
                    TapGesture(count: 2)
                        .onEnded {
                            if !model.supportsEnabled {
                                model.triggerMotorOffDoubleTap()
                            }
                        }
                )
            }
            .onAppear {
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { _, _ in
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(alignment: .bottomLeading) {
            Text(model.supportsEnabled ? "Tap the large button" : "Use long-press or double-tap quickly")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(12)
        }
    }
    
    private var neurodiversityStage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text(model.supportsEnabled ? "Cognitive Load: Low" : "Cognitive Load: High")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(model.supportsEnabled ? .green : .orange)
                
                if model.supportsEnabled {
                    Text(cognitiveStageContent.heading)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(cognitiveStageContent.structuredBullets, id: \.self) { bullet in
                            Text("• \(bullet)")
                        }
                    }
                    .font(.body)
                } else {
                    Text(cognitiveStageContent.unstructuredParagraph)
                        .font(.body)
                }
                
                VStack(spacing: 10) {
                    ForEach(Array(cognitiveStageContent.choices.enumerated()), id: \.offset) { _, choice in
                        Button(choice.label) {
                            model.triggerCognitiveChoice(isCorrect: choice.isCorrect)
                        }
                        .padding(.vertical, 10)
                        .frame(maxWidth: .infinity)
                        .background(
                            model.supportsEnabled
                            ? Color.blue
                            : Color(.secondarySystemBackground),
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                        )
                        .foregroundColor(model.supportsEnabled ? .white : .primary)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    
    private var interstitialView: some View {
        VStack(spacing: 18) {
            Spacer()
            Label("Reflection", systemImage: "lightbulb.fill")
                .font(.system(.headline, design: .rounded).weight(.semibold))
            Text("Notice that frustration? Lets see how different it would be if the campus were to implement disability support features.")
                .font(.system(.title3, design: .rounded).weight(.bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            Button("Start Simulation with Supports") {
                withAnimation(.spring()) {
                    model.enableSupportsFromInterstitial()
                }
            }
            .buttonStyle(.borderedProminent)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
    
    private func feedbackOverlay(_ feedback: StageFeedback) -> some View {
        ZStack {
            Color.black.opacity(0.25).ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Label("Stage Reflection", systemImage: "checkmark.seal.fill")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                Text(feedback.barrier)
                    .font(.subheadline)
                Text(feedback.fix)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                
                Button("Continue") {
                    withAnimation(.spring()) {
                        model.advanceFromFeedback()
                    }
                }
                .buttonStyle(.borderedProminent)
                .shadow(color: .black.opacity(0.15), radius: 3, x: 0, y: 2)
            }
            .padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .padding(24)
        }
        .transition(.opacity)
    }
    
    private var cognitiveStageContent: (heading: String, unstructuredParagraph: String, structuredBullets: [String], choices: [(label: String, isCorrect: Bool)]) {
        switch model.currentStepIndex {
        case 0:
            return (
                heading: "Entrance Access",
                unstructuredParagraph: "Before you try to enter, take a second to confirm which entry method is active today because the usual flow changes depending on whether the access keypad is currently being used for student check in or whether you are supposed to pause near the service area until someone verifies your name, and if you do not see a clear sign immediately you should avoid forcing the main door and instead either wait briefly where deliveries are typically staged or use the side entry control that sometimes confirms access faster, but only after you are sure you are not bypassing the hold instruction that applies when staffing is limited.",
                structuredBullets: [
                    "Use the side door keypad for building entry.",
                    "Wait for confirmation, then proceed inside.",
                    "Ignore temporary notices that do not change this step."
                ],
                choices: [
                    ("Use side door keypad", true),
                    ("Wait by loading dock", false)
                ]
            )
        case 1:
            return (
                heading: "Elevator Routing",
                unstructuredParagraph: "As you reach the elevator area, keep in mind that the lab related spaces are split across multiple floors and the signage can be misleading because some directions reference check in on a lower level while other directions reference the main lab corridor upstairs, so if the instruction you received mentions both a quick stop and the final destination you may be tempted to select the nearer floor first, but if your goal is to arrive at the robotics lab without adding an extra loop you should choose the floor that aligns with the lab corridor even if another floor is mentioned as an intermediate point for equipment pickup.",
                structuredBullets: [
                    "Go to the elevator panel.",
                    "Select Floor 4.",
                    "Continue to the lab corridor after arrival."
                ],
                choices: [
                    ("Press Floor 4", true),
                    ("Press Floor 2", false)
                ]
            )
        default:
            return (
                heading: "Lab Door Entry",
                unstructuredParagraph: "At the lab door, the process can feel like it depends on timing and small cues because sometimes the reader takes a moment to register and sometimes the handle will move slightly even when it is not fully unlocked, so if you are unsure whether the badge tap registered you might try the handle quickly to see if it gives, but the safer sequence is to make sure the reader actually completes the scan first since repeated pulling can happen before the authorization finishes, and if you do not notice the confirmation right away you should pause, re align, and try again in the way that produces the green indicator rather than relying on the handle movement to tell you the status.",
                structuredBullets: [
                    "Tap your badge at the reader.",
                    "Hold until the indicator turns green.",
                    "Open the door after confirmation."
                ],
                choices: [
                    ("Tap badge and hold", true),
                    ("Pull handle twice", false)
                ]
            )
        }
    }
}

private extension GeometryProxy {
    var safeAreaInsetsAdjustedFrame: CGRect {
        CGRect(
            x: safeAreaInsets.leading,
            y: safeAreaInsets.top,
            width: size.width - safeAreaInsets.leading - safeAreaInsets.trailing,
            height: size.height - safeAreaInsets.top - safeAreaInsets.bottom
        )
    }
}
