import SwiftUI

struct ScenarioView: View {
    @EnvironmentObject var model: AppModel
    @State private var promptPulse = false
    
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Color(.systemBackground).ignoresSafeArea()
                
                if model.showEducationalInterstitial {
                    interstitialView
                } else {
                    VStack(spacing: 14) {
                        header
                        stageBody
                    }
                    .padding()
                }
                
                if showSupportPrompt {
                    supportPrompt
                        .padding(.top, 8)
                }
                
                if let feedback = model.stageFeedback {
                    feedbackOverlay(feedback)
                }
            }
            .onAppear {
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.beginLensSessionIfNeeded()
                withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) {
                    promptPulse = true
                }
            }
            .onChange(of: geo.size) { _, _ in
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.configureCurrentStage()
            }
            .onChange(of: model.currentStepIndex) { _, _ in
                model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                model.configureCurrentStage()
            }
            .onReceive(timer) { _ in
                model.updateMotorTimeout()
            }
        }
    }
    
    private var showSupportPrompt: Bool {
        model.isFirstPlaythroughComplete && !model.supportsEnabled && !model.showEducationalInterstitial && model.stageFeedback == nil
    }
    
    private var supportPrompt: some View {
        HStack(spacing: 8) {
            Image(systemName: "arrow.up.circle.fill")
                .font(.title3)
                .offset(y: promptPulse ? -4 : 4)
            Text("Design is currently inaccessible. Turn on Supports to fix.")
                .font(.footnote.weight(.semibold))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial, in: Capsule())
    }
    
    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label(model.currentScenario.name, systemImage: "book.fill")
                    .font(.system(.title2, design: .rounded).weight(.bold))
                Spacer()
                if model.isCurrentLensCompleted {
                    Toggle("Supports", isOn: $model.supportsEnabled)
                        .labelsHidden()
                }
            }
            
            if model.shouldShowProgress {
                ProgressView(value: model.progress)
                    .tint(.blue)
                Text(model.stepLabel)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            
            Text(model.currentScenario.steps[model.currentStepIndex].title)
                .font(.system(.headline, design: .rounded))
            Text(model.currentScenario.steps[model.currentStepIndex].description)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: .black.opacity(0.2), radius: 6, x: 0, y: 3)
    }
    
    @ViewBuilder
    private var stageBody: some View {
        switch model.currentLens {
        case .blindness:
            blindnessStage
        case .motorImpairment:
            motorStage
        case .neurodiversity:
            neurodiversityStage
        case .none:
            EmptyView()
        }
    }
    
    private var blindnessStage: some View {
        GeometryReader { localGeo in
            ZStack {
                // Bottom: hidden target
                Button {
                    model.triggerBlindnessAction()
                } label: {
                    Text(model.currentScenario.steps[model.currentStepIndex].actionLabelOn)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(height: model.supportsEnabled ? 64 : 52)
                        .frame(minWidth: model.supportsEnabled ? 220 : 170)
                        .background(model.isButtonRevealed ? Color.green : Color.clear, in: Capsule())
                }
                .position(model.realButtonPosition)
                .disabled(!model.isButtonRevealed)
                .opacity(model.isButtonRevealed ? (model.supportsEnabled ? model.blindnessPulseOpacity : 1) : 0.01)
                .shadow(color: .green.opacity(model.isButtonRevealed ? (model.supportsEnabled ? 0.45 : 0.65) : 0), radius: model.supportsEnabled ? 8 : 10, x: 0, y: 0)
                
                if !model.supportsEnabled {
                    ForEach(Array(model.blindnessDecoyPositions.enumerated()), id: \.offset) { _, decoyPosition in
                        Button {
                            // distraction only
                        } label: {
                            Capsule()
                                .fill(Color.red)
                                .frame(width: 120, height: 44)
                        }
                        .position(decoyPosition)
                        .buttonStyle(.plain)
                    }
                }
                
                if !model.isButtonRevealed {
                    // Middle + mask: punch-through darkness
                    Rectangle()
                        .fill(Color.black)
                        .mask(
                            ZStack {
                                Rectangle().fill(Color.white)
                                if let flashlightLocation = model.flashlightPoint {
                                    Circle()
                                        .fill(
                                            RadialGradient(
                                                colors: [.black, .black.opacity(0.45), .clear],
                                                center: .center,
                                                startRadius: 1,
                                                endRadius: model.flashlightRadius
                                            )
                                        )
                                        .frame(width: model.flashlightRadius * 2, height: model.flashlightRadius * 2)
                                        .position(flashlightLocation)
                                        .blur(radius: 1.2)
                                        .blendMode(.destinationOut)
                                }
                            }
                                .compositingGroup()
                        )
                        .allowsHitTesting(false)
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged { value in
                        if model.flashlightPoint == nil {
                            model.beginBlindnessFlashlight(at: value.location)
                        } else {
                            model.moveBlindnessFlashlight(to: value.location)
                        }
                    }
                    .onEnded { _ in
                        model.endBlindnessFlashlight()
                    }
            )
            .onAppear {
                model.setupStage(in: localGeo.size)
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { _, newSize in
                model.setupStage(in: newSize)
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    
    private var motorStage: some View {
        GeometryReader { localGeo in
            ZStack {
                Color(.secondarySystemBackground)
                Button {
                    if model.supportsEnabled {
                        model.triggerMotorTap()
                    }
                } label: {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(.blue)
                        .frame(width: model.supportsEnabled ? 220 : 15, height: model.supportsEnabled ? 60 : 15)
                        .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
                }
                .position(model.motorButtonPosition)
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.6)
                        .onEnded { _ in if !model.supportsEnabled { model.triggerMotorOffLongPress() } }
                )
                .simultaneousGesture(
                    TapGesture(count: 2)
                        .onEnded { if !model.supportsEnabled { model.triggerMotorOffDoubleTap() } }
                )
            }
            .onAppear {
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { _, _ in
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(alignment: .bottomLeading) {
            Text(model.supportsEnabled ? "Tap the large button" : "Use long-press or double-tap quickly")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(12)
        }
    }
    
    private var neurodiversityStage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if model.supportsEnabled {
                    Text(model.currentScenario.steps[model.currentStepIndex].title)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Label("What to do", systemImage: "list.bullet.rectangle.portrait")
                        .font(.headline)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("• Read the short instruction")
                        Text("• Confirm the next action")
                        Text("• Continue to the next stage")
                    }
                    .font(.body)
                    
                    Button(model.currentScenario.steps[model.currentStepIndex].actionLabelOn) {
                        model.triggerNeuroAction()
                    }
                    .buttonStyle(.borderedProminent)
                    .shadow(color: .black.opacity(0.15), radius: 3, x: 0, y: 2)
                } else {
                    Text(loremText).font(.body)
                    Text(loremText).font(.body)
                    Text(loremText).font(.body)
                    Text(loremText).font(.body)
                    
                    HStack {
                        Button("Click here") { model.triggerNeuroAction() }
                            .buttonStyle(.bordered)
                        Button("Proceed") { model.triggerNeuroAction() }
                            .buttonStyle(.bordered)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    
    private var interstitialView: some View {
        VStack(spacing: 18) {
            Spacer()
            Label("Educational Interstitial", systemImage: "lightbulb.fill")
                .font(.system(.headline, design: .rounded).weight(.semibold))
            Text("You have experienced the design barriers. Now, see how Inclusive Design fixes them.")
                .font(.system(.title3, design: .rounded).weight(.bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            Button("Start Simulation with Supports") {
                withAnimation(.spring()) {
                    model.enableSupportsFromInterstitial()
                }
            }
            .buttonStyle(.borderedProminent)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
    
    private func feedbackOverlay(_ feedback: StageFeedback) -> some View {
        ZStack {
            Color.black.opacity(0.25).ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Label("Stage Reflection", systemImage: "checkmark.seal.fill")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                Text(feedback.barrier)
                    .font(.subheadline)
                Text(feedback.fix)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                
                Button("Continue") {
                    withAnimation(.spring()) {
                        model.advanceFromFeedback()
                    }
                }
                .buttonStyle(.borderedProminent)
                .shadow(color: .black.opacity(0.15), radius: 3, x: 0, y: 2)
            }
            .padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .padding(24)
        }
        .transition(.opacity)
    }
    
    private var loremText: String {
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non massa in augue malesuada tristique. Integer tincidunt, nibh eget facilisis aliquam, augue sapien venenatis mi, vitae varius eros nisi non nibh."
    }
}

private extension GeometryProxy {
    var safeAreaInsetsAdjustedFrame: CGRect {
        CGRect(
            x: safeAreaInsets.leading,
            y: safeAreaInsets.top,
            width: size.width - safeAreaInsets.leading - safeAreaInsets.trailing,
            height: size.height - safeAreaInsets.top - safeAreaInsets.bottom
        )
    }
}
