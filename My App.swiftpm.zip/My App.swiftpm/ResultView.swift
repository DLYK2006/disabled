import SwiftUI

struct ResultView: View {
    @EnvironmentObject var model: AppModel
    
    var isBadEnding: Bool { model.frictionPoints >= 1 }
    
    var body: some View {
        ZStack {
            (isBadEnding ? Color.black : Color.white).ignoresSafeArea()
            
            VStack(spacing: 40) {
                Spacer()
                
                Circle()
                    .stroke(isBadEnding ? Color.red : Color.blue, lineWidth: 4)
                    .frame(width: 120, height: 120)
                    .overlay(
                        Image(systemName: isBadEnding ? "bolt.slash.fill" : "person.2.fill")
                            .font(.system(size: 50))
                            .foregroundColor(isBadEnding ? .red : .blue)
                    )
                
                VStack(spacing: 20) {
                    Text(isBadEnding ? "THE WALL OF EXCLUSION" : "THE POWER OF ACCESS")
                        .font(.system(.title, design: .monospaced))
                        .bold()
                        .foregroundColor(isBadEnding ? .red : .primary)
                    
                    Text(getEndingStory())
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .foregroundColor(isBadEnding ? .white : .secondary)
                }
                
                Spacer()
                
                Button(action: { model.reset() }) {
                    Text(isBadEnding ? "REBUILD WITH EMPATHY" : "CHOOSE ANOTHER LENS")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(isBadEnding ? Color.red : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                .padding(.horizontal)
            }
            .padding()
        }
    }
    
    func getEndingStory() -> String {
        if isBadEnding {
            return "The friction won. You spent so much energy fighting the interface that you arrived late and exhausted. This is what exclusion feels like."
        } else {
            return "By using inclusive design, the environment worked for you. This is what access feels like."
        }
    }
}
