import SwiftUI

struct ReflectionView: View {
    @ObservedObject var model: AppModel
    var onDone: () -> Void
    
    @State private var pageIndex: Int = 0
    
    var body: some View {
        VStack(spacing: 28) {
            Spacer()
            
            VStack(spacing: 14) {
                Text(titleText)
                    .font(.system(.largeTitle, design: .rounded).bold())
                
                Text(bodyText)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
            }
            
            Spacer()
            
            if pageIndex < 2 {
                Text("Tap to continue")
                    .font(.headline)
                    .foregroundStyle(.secondary)
                    .padding(.bottom, 12)
            } else {
                Button {
                    onDone()
                } label: {
                    Text("Finish")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.blue, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .foregroundColor(.white)
                }
                .padding(.horizontal)
                .padding(.bottom, 12)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            if pageIndex < 2 {
                withAnimation(.spring()) {
                    pageIndex += 1
                }
            }
        }
    }
    
    private var titleText: String {
        if pageIndex == 2 {
            return ""
        } else {
            return "Reflection"
        }
    }
    
    private var bodyText: String {
        if pageIndex == 0 {
            return "Now that you had a peek of how life is for the disabled..."
        } else if pageIndex == 1 {
            return "More than 1.3 billion people worldwide live with some form of disability. That is roughly 1 in 6 people."
        } else {
            return "You've seen how disability support features make a difference. Lets spread the word and encourage more implementation, everyone deserves a chance at experiencing life."
        }
    }
}
