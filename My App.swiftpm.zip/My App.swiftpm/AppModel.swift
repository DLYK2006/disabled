import SwiftUI

struct StageFeedback {
    let barrier: String
    let fix: String
}

enum AppPhase {
    case barriers
    case solutions
}

final class AppModel: ObservableObject {
    @Published var currentLens: LensType? = nil {
        didSet {
            guard currentLens != oldValue, let lens = currentLens else { return }
            handleLensSelection(lens)
        }
    }
    @Published var currentStepIndex: Int = 0
    @Published var supportsEnabled: Bool = false
    @Published var showResult: Bool = false
    
    @Published var frictionPoints: Int = 0
    @Published var isFirstPlaythroughComplete: Bool = false
    @Published var currentPhase: AppPhase = .barriers
    @Published var showEducationalInterstitial: Bool = false
    @Published var completedLenses: Set<LensType> = []
    
    @Published var stageFeedback: StageFeedback? = nil
    
    // Blindness
    @Published var realButtonPosition: CGPoint = .zero
    @Published var isButtonRevealed: Bool = false
    @Published var flashlightPoint: CGPoint? = nil
    @Published var flashlightRadius: CGFloat = 80
    @Published var flashlightOpacity: Double = 0
    @Published var blindnessPulseOpacity: Double = 1
    @Published var blindnessDecoyPositions: [CGPoint] = []
    
    
    // Motor
    @Published var motorButtonPosition: CGPoint = .zero
    @Published var motorTaps: Int = 0
    
    private var stageBounds: CGRect = CGRect(x: 0, y: 0, width: 375, height: 700)
    private var motorTimeoutStart = Date()
    
    var currentScenario: Scenario {
        guard let lens = currentLens else { return ScenarioData.blindnessScenario }
        switch lens {
        case .blindness: return ScenarioData.blindnessScenario
        case .motorImpairment: return ScenarioData.motorImpairmentScenario
        case .neurodiversity: return ScenarioData.neurodiversityScenario
        }
    }
    
    var progress: Double { Double(currentStepIndex + 1) / 3.0 }
    var shouldShowProgress: Bool { currentLens != .neurodiversity || supportsEnabled }
    var stepLabel: String { "Step \(currentStepIndex + 1) of 3" }
    var isCurrentLensCompleted: Bool {
        guard let lens = currentLens else { return false }
        return completedLenses.contains(lens)
    }
    
    func beginLensSessionIfNeeded() {
        guard currentLens != nil else { return }
        if currentPhase != .barriers || supportsEnabled || currentStepIndex != 0 || stageFeedback != nil { return }
        configureCurrentStage()
    }
    
    func setStageBounds(_ rect: CGRect) {
        stageBounds = rect
    }
    
    func setupStage(in size: CGSize) {
        stageBounds = CGRect(origin: .zero, size: size)
        
        let xMin: CGFloat = 100
        let xMax: CGFloat = max(xMin, min(300, size.width - 100))
        let yMin: CGFloat = 200
        let yMax: CGFloat = max(yMin, min(500, size.height - 200))
        
        realButtonPosition = CGPoint(x: CGFloat.random(in: xMin...xMax), y: CGFloat.random(in: yMin...yMax))
        randomizeBlindnessDecoyPositions()
        isButtonRevealed = false
        motorTaps = 0
    }
    
    func configureCurrentStage() {
        guard let lens = currentLens else { return }
        
        switch lens {
        case .blindness:
            isButtonRevealed = false
            flashlightPoint = nil
            flashlightOpacity = 0
            flashlightRadius = supportsEnabled ? 130 : 55
            if supportsEnabled {
                withAnimation(.spring(response: 0.9, dampingFraction: 0.7).repeatForever(autoreverses: true)) {
                    blindnessPulseOpacity = 0.5
                }
            } else {
                blindnessPulseOpacity = 1
            }
            
        case .motorImpairment:
            motorTaps = 0
            placeMotorButton()
            motorTimeoutStart = Date()
            
        case .neurodiversity:
            break
        }
    }
    
    func beginBlindnessFlashlight(at point: CGPoint) {
        guard currentLens == .blindness, stageFeedback == nil else { return }
        
        flashlightPoint = point
        flashlightRadius = supportsEnabled ? 130 : 55
        flashlightOpacity = 1
        updateBlindnessRevealState(at: point)
    }
    
    func moveBlindnessFlashlight(to point: CGPoint) {
        guard currentLens == .blindness, stageFeedback == nil else { return }
        
        flashlightPoint = point
        flashlightOpacity = 1
        updateBlindnessRevealState(at: point)
    }
    
    func endBlindnessFlashlight() {
        guard currentLens == .blindness else { return }
        withAnimation(.easeOut(duration: 0.2)) {
            flashlightOpacity = 0
        }
        flashlightPoint = nil
    }
    
    private func updateBlindnessRevealState(at point: CGPoint) {
        guard !isButtonRevealed else { return }
        let revealThreshold: CGFloat = supportsEnabled ? 90 : 45
        let distance = sqrt(pow(point.x - realButtonPosition.x, 2) + pow(point.y - realButtonPosition.y, 2))
        if distance < revealThreshold {
            withAnimation(.spring()) {
                isButtonRevealed = true
            }
        }
    }
    
    
    private func randomizeBlindnessDecoyPositions() {
        let playableRect = CGRect(
            x: 70,
            y: 120,
            width: max(120, stageBounds.width - 140),
            height: max(220, stageBounds.height - 220)
        )
        
        let minSpacing: CGFloat = 180
        
        func candidatePoint() -> CGPoint {
            CGPoint(
                x: CGFloat.random(in: playableRect.minX...playableRect.maxX),
                y: CGFloat.random(in: playableRect.minY...playableRect.maxY)
            )
        }
        
        while true {
            let first = candidatePoint()
            guard hypot(first.x - realButtonPosition.x, first.y - realButtonPosition.y) >= minSpacing else { continue }
            
            let second = candidatePoint()
            let secondFarFromReal = hypot(second.x - realButtonPosition.x, second.y - realButtonPosition.y) >= minSpacing
            let secondFarFromFirst = hypot(second.x - first.x, second.y - first.y) >= minSpacing
            
            if secondFarFromReal && secondFarFromFirst {
                blindnessDecoyPositions = [first, second]
                return
            }
        }
    }
    func triggerBlindnessAction() {
        guard currentLens == .blindness, stageFeedback == nil else { return }
        guard isButtonRevealed else { return }
        stageCompleted()
    }
    
    func triggerMotorTap() {
        guard currentLens == .motorImpairment, supportsEnabled, stageFeedback == nil else { return }
        stageCompleted()
    }
    
    func triggerMotorOffDoubleTap() {
        guard currentLens == .motorImpairment, !supportsEnabled, stageFeedback == nil else { return }
        handleMotorBarrierHit()
    }
    
    func triggerMotorOffLongPress() {
        guard currentLens == .motorImpairment, !supportsEnabled, stageFeedback == nil else { return }
        handleMotorBarrierHit()
    }
    
    func triggerCognitiveChoice(isCorrect: Bool) {
        guard currentLens == .neurodiversity, stageFeedback == nil else { return }
        
        if !isCorrect {
            frictionPoints += 1
        }
        
        let step = currentScenario.steps[currentStepIndex]
        let feedback: StageFeedback
        if supportsEnabled {
            feedback = StageFeedback(
                barrier: "Disability support made it easier for people with Cognitive Load issues",
                fix: step.fix
            )
        } else {
            feedback = StageFeedback(
                barrier: step.barrier,
                fix: "Not quite , but that's ok."
            )
        }
        
        withAnimation(.spring()) {
            stageFeedback = feedback
        }
    }
    
    func triggerNeuroAction() {
        guard currentLens == .neurodiversity, stageFeedback == nil else { return }
        stageCompleted()
    }
    
    func updateMotorTimeout() {
        guard currentLens == .motorImpairment, !supportsEnabled, stageFeedback == nil else { return }
        if Date().timeIntervalSince(motorTimeoutStart) >= 3 {
            frictionPoints += 1
            placeMotorButton()
            motorTimeoutStart = Date()
        }
    }
    
    func advanceFromFeedback() {
        stageFeedback = nil
        advanceProtocol()
    }
    
    func enableSupportsFromInterstitial() {
        guard showEducationalInterstitial else { return }
        withAnimation(.spring()) {
            showEducationalInterstitial = false
            supportsEnabled = true
            currentPhase = .solutions
            currentStepIndex = 0
        }
        setupStage(in: stageBounds.size)
        configureCurrentStage()
    }
    
    func nextStep() {
        withAnimation(.spring()) {
            currentStepIndex += 1
        }
        
        setupStage(in: stageBounds.size)
        configureCurrentStage()
    }
    
    func reset() {
        currentLens = nil
        currentStepIndex = 0
        supportsEnabled = false
        currentPhase = .barriers
        showEducationalInterstitial = false
        stageFeedback = nil
        showResult = false
        isButtonRevealed = false
        flashlightPoint = nil
        flashlightOpacity = 0
        motorTaps = 0
    }
    
    private func stageCompleted() {
        let step = currentScenario.steps[currentStepIndex]
        withAnimation(.spring()) {
            stageFeedback = StageFeedback(barrier: step.barrier, fix: step.fix)
        }
    }
    
    private func advanceProtocol() {
        if currentStepIndex < 2 {
            nextStep()
            return
        }
        
        if currentPhase == .barriers {
            withAnimation(.spring()) {
                showEducationalInterstitial = true
            }
            return
        }
        
        finishLensSession()
    }
    
    private func finishLensSession() {
        if let lens = currentLens {
            completedLenses.insert(lens)
        }
        withAnimation(.spring()) {
            isFirstPlaythroughComplete = true
        }
        reset()
    }
    
    private func handleLensSelection(_ lens: LensType) {
        isFirstPlaythroughComplete = completedLenses.contains(lens)
        supportsEnabled = false
        currentPhase = .barriers
        showEducationalInterstitial = false
        currentStepIndex = 0
        stageFeedback = nil
        setupStage(in: stageBounds.size)
        configureCurrentStage()
    }
    
    private func handleMotorBarrierHit() {
        motorTaps += 1
        
        if motorTaps < 3 {
            placeMotorButton()
            motorTimeoutStart = Date()
            return
        }
        
        if currentPhase == .barriers && currentStepIndex == 2 {
            withAnimation(.spring()) {
                showEducationalInterstitial = true
            }
            return
        }
        
        stageCompleted()
    }
    
    private func placeMotorButton() {
        let w = stageBounds.width
        let h = stageBounds.height
        let minX = stageBounds.minX
        let minY = stageBounds.minY
        
        let xMin = minX + 50
        let xMax = max(xMin, minX + w - 50)
        
        if supportsEnabled {
            let yMin = minY + max(100, h * 0.5)
            let yMax = max(yMin, minY + h - 100)
            motorButtonPosition = CGPoint(
                x: CGFloat.random(in: xMin...xMax),
                y: CGFloat.random(in: yMin...yMax)
            )
            return
        }
        
        let yMin = minY + 100
        let yMax = max(yMin, minY + h - 100)
        motorButtonPosition = CGPoint(
            x: CGFloat.random(in: xMin...xMax),
            y: CGFloat.random(in: yMin...yMax)
        )
    }
}
