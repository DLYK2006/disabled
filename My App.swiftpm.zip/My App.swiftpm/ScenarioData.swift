import SwiftUI

struct Scenario {
    let name: String
    let steps: [ScenarioStep]
}

struct ScenarioStep: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let barrier: String
    let fix: String
    let actionLabelOff: String
    let actionLabelOn: String
}

struct Choice: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let isReal: Bool
    let barrierOutcome: String
    let supportOutcome: String
}

enum LensType: String, CaseIterable, Identifiable {
    case blindness = "Blindness"
    case motorImpairment = "Fine Motor Impairment"
    case neurodiversity = "Cognitive Load & Structure"
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .blindness: return "eye.slash.fill"
        case .motorImpairment: return "hand.raised.slash"
        case .neurodiversity: return "brain.head.profile"
        }
    }
}

struct ScenarioData {
    static let blindnessScenario = Scenario(name: "Blindness", steps: [
        ScenarioStep(
            title: "Entrance",
            description: "Locate the door button amongst other buttons in complete darkness.",
            barrier: "Good job! You found the door button",
            fix: "You continue onwards to the elevator in the lobby.",
            actionLabelOff: "Search",
            actionLabelOn: "Open door"
        ),
        ScenarioStep(
            title: "Elevator",
            description: "Find and activate the floor control.",
            barrier: "You felt the correct floor button and pressed it",
            fix: "Continue out to the floor",
            actionLabelOff: "Find Floor",
            actionLabelOn: "Press button"
        ),
        ScenarioStep(
            title: "Door",
            description: "Find the door handle",
            barrier: "You felt around for the door handle and pulled it",
            fix: "You then walked into class successfully",
            actionLabelOff: "Locate",
            actionLabelOn: "Pull door"
        )
    ])
    
    static let motorImpairmentScenario = Scenario(name: "Motor Impairment", steps: [
        ScenarioStep(
            title: "Gate Button",
            description: "Press the button to advance",
            barrier: "After multiple tries , you pressed the gate button and you advanced",
            fix: "You walked to the cafeteria to get something to eat",
            actionLabelOff: "Proceed",
            actionLabelOn: "Next: Gate"
        ),
        ScenarioStep(
            title: "Kiosk Confirm",
            description: "Order your favourite burger from the kiosk",
            barrier: "You successfully ordered your burger from the kiosk",
            fix: "You get ready to go to your lab class",
            actionLabelOff: "Click here",
            actionLabelOn: "Next: Kiosk"
        ),
        ScenarioStep(
            title: "Lab Access",
            description: "Tap your access card on the scanner",
            barrier: "You manage to scan your card on the scanner",
            fix: "You successfully made it to class!",
            actionLabelOff: "Do it",
            actionLabelOn: "Next: Lab Access"
        )
    ])
    
    static let neurodiversityScenario = Scenario(name: "Cognitive Load & Structure", steps: [
        ScenarioStep(
            title: "Entrance",
            description: "Interpret the entry instructions and choose the intended action.",
            barrier: "Barrier: Information is delivered as one dense block, so the key action is hard to prioritize.",
            fix: "Support: Clear hierarchy, short bullets, and one primary action reduce mental effort.",
            actionLabelOff: "Use side door keypad",
            actionLabelOn: "Use side door keypad"
        ),
        ScenarioStep(
            title: "Elevator",
            description: "Determine the correct floor action from mixed-priority instructions.",
            barrier: "Barrier: Excess details and weak structure make wayfinding decisions slower.",
            fix: "Support: Grouped steps and plain language make the correct floor choice obvious.",
            actionLabelOff: "Press Floor 4",
            actionLabelOn: "Press Floor 4"
        ),
        ScenarioStep(
            title: "Lab Door",
            description: "Complete entry by selecting the single required safety/action step.",
            barrier: "Barrier: Competing details hide the required action and increase cognitive load.",
            fix: "Support: Concise instructions and explicit priority improve confidence and accuracy.",
            actionLabelOff: "Tap badge and hold",
            actionLabelOn: "Tap badge and hold"
        )
    ])
}
