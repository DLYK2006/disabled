import SwiftUI

struct Scenario {
    let name: String
    let steps: [ScenarioStep]
}

struct ScenarioStep: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let barrier: String
    let fix: String
    let actionLabelOff: String
    let actionLabelOn: String
}

struct Choice: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let isReal: Bool
    let barrierOutcome: String
    let supportOutcome: String
}

enum LensType: String, CaseIterable, Identifiable {
    case blindness = "Blindness"
    case motorImpairment = "Motor Impairment"
    case neurodiversity = "Neurodiversity"
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .blindness: return "eye.slash.fill"
        case .motorImpairment: return "hand.raised.slash"
        case .neurodiversity: return "brain.head.profile"
        }
    }
}

struct ScenarioData {
    static let blindnessScenario = Scenario(name: "Blindness", steps: [
        ScenarioStep(
            title: "Entrance",
            description: "Locate the control in complete darkness.",
            barrier: "Barrier: No visual affordance; control cannot be discovered quickly.",
            fix: "Fix: Visible, high-contrast control with clear focus state.",
            actionLabelOff: "Search",
            actionLabelOn: "Activate Entrance"
        ),
        ScenarioStep(
            title: "Elevator",
            description: "Find and activate the floor control.",
            barrier: "Barrier: Invisible target and no guidance.",
            fix: "Fix: Persistent visible control with pulsing prominence.",
            actionLabelOff: "Find Floor",
            actionLabelOn: "Activate Elevator"
        ),
        ScenarioStep(
            title: "Door",
            description: "Complete the final action.",
            barrier: "Barrier: Hidden final interaction.",
            fix: "Fix: Clear, visible call-to-action with consistent placement.",
            actionLabelOff: "Locate",
            actionLabelOn: "Unlock Door"
        )
    ])
    
    static let motorImpairmentScenario = Scenario(name: "Motor Impairment", steps: [
        ScenarioStep(
            title: "Gate Button",
            description: "Activate a tiny, hard-to-reach target three times before stage success.",
            barrier: "Barrier: 15pt target violates 44pt minimum hit-area.",
            fix: "Fix: 60pt target in thumb zone with simple single tap.",
            actionLabelOff: "Proceed",
            actionLabelOn: "Next: Gate"
        ),
        ScenarioStep(
            title: "Kiosk Confirm",
            description: "Hit a tiny control three times before the stage can clear.",
            barrier: "Barrier: Top-edge placement increases precision demand.",
            fix: "Fix: Centered control reduces reach and strain.",
            actionLabelOff: "Click here",
            actionLabelOn: "Next: Kiosk"
        ),
        ScenarioStep(
            title: "Lab Access",
            description: "Complete three accurate tiny-target activations.",
            barrier: "Barrier: Time pressure + tiny targets causes repeated misses.",
            fix: "Fix: Large forgiving target with immediate feedback.",
            actionLabelOff: "Do it",
            actionLabelOn: "Next: Lab Access"
        )
    ])
    
    static let neurodiversityScenario = Scenario(name: "Neurodiversity", steps: [
        ScenarioStep(
            title: "Orientation",
            description: "Understand what to do next.",
            barrier: "Barrier: Dense text and vague labels increase cognitive load.",
            fix: "Fix: Chunked bullets, clear heading, and explicit next action.",
            actionLabelOff: "Proceed",
            actionLabelOn: "Next: Orientation"
        ),
        ScenarioStep(
            title: "Instructions",
            description: "Follow guidance accurately.",
            barrier: "Barrier: No progress signal creates uncertainty.",
            fix: "Fix: Visible progress and plain-language labels.",
            actionLabelOff: "Click here",
            actionLabelOn: "Next: Instructions"
        ),
        ScenarioStep(
            title: "Completion",
            description: "Finish the flow confidently.",
            barrier: "Barrier: Cluttered hierarchy hides key action.",
            fix: "Fix: One primary action with strong visual hierarchy.",
            actionLabelOff: "Continue",
            actionLabelOn: "Finish: Completion"
        )
    ])
}
