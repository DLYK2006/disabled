import SwiftUI

struct HomeView: View {
    @ObservedObject var model: AppModel
    var onReflection: () -> Void = {}
    
    private var allLensesCompleted: Bool {
        model.completedLenses.count == LensType.allCases.count
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("Accessibility Lenses")
                    .font(.system(.largeTitle, design: .rounded).bold())
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Pick a lens from below")
                        .font(.headline)
                    Text("You will experience first-hand the difficulties of day to day life in their POV")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(Color(.secondarySystemBackground))
                )
                
                ForEach(Array(LensType.allCases), id: \.self) { lens in
                    Button {
                        model.currentLens = lens
                    } label: {
                        HStack(spacing: 16) {
                            ZStack {
                                Circle()
                                    .fill(Color.blue.opacity(0.1))
                                    .frame(width: 50, height: 50)
                                Image(systemName: lens.icon)
                                    .foregroundColor(.blue)
                                    .font(.title3)
                            }
                            
                            VStack(alignment: .leading) {
                                Text(lens.rawValue)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            }
                            
                            Spacer()
                            
                            if model.completedLenses.contains(lens) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .font(.title2)
                            } else {
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color(.secondarySystemBackground))
                        )
                    }
                }
                
                if allLensesCompleted {
                    Button {
                        onReflection()
                    } label: {
                        Text("Reflection")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.blue, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .foregroundColor(.white)
                    }
                    .padding(.top, 12)
                }
            }
            .padding()
        }
    }
}
