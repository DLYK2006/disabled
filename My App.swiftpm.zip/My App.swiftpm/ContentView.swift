import SwiftUI

struct ContentView: View {
    @StateObject private var model = AppModel()
    @State private var hasStarted = false
    @State private var showReflection = false
    
    var body: some View {
        Group {
            if !hasStarted {
                StartView(hasStarted: $hasStarted)
            } else if showReflection {
                ReflectionView(model: model) {
                    showReflection = false
                }
            } else {
                if model.currentLens == nil {
                    HomeView(model: model) {
                        showReflection = true
                    }
                } else {
                    ScenarioView()
                        .environmentObject(model)
                }
            }
        }
    }
}
