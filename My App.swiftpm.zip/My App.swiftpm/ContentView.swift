import SwiftUI

struct ContentView: View {
    @StateObject private var model = AppModel()
    
    var body: some View {
        NavigationView {
            VStack {
                if model.showResult {
                    Text("Results Screen Placeholder")
                } else if model.currentLens != nil {
                    ScenarioView()
                        .environmentObject(model)
                } else {
                    HomeView(model: model)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if model.currentLens != nil {
                        Button("Exit") {
                            model.reset()
                        }
                        .foregroundColor(.red)
                    }
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
