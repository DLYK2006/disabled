import SwiftUI

struct StartView: View {
    @Binding var hasStarted: Bool
    @State private var pageIndex: Int = 0
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 28) {
                Text("Perspective")
                    .font(.system(.largeTitle, design: .rounded).weight(.semibold))
                
                Text(bodyText)
                    .font(.title3.weight(.regular))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 36)
                    .transition(.opacity)
            }
            
            Spacer()
            
            Text("Tap anywhere to continue")
                .font(.footnote.weight(.medium))
                .foregroundStyle(.secondary.opacity(0.7))
                .padding(.bottom, 28)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.25)) {
                if pageIndex == 0 {
                    pageIndex = 1
                } else {
                    hasStarted = true
                }
            }
        }
        .padding()
    }
    
    private var bodyText: String {
        if pageIndex == 0 {
            return "A quiet exploration of accessibility."
        } else {
            return "You’ll experience everyday tasks through different perspectives, first without support, then with it."
        }
    }
}
