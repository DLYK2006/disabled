import SwiftUI

struct ReflectionView: View {
    @ObservedObject var model: AppModel
    var onDone: () -> Void
    
    @State private var pageIndex: Int = 0
    
    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            
            VStack(spacing: 14) {
                Text(titleText)
                    .font(.system(.largeTitle, design: .rounded).weight(.semibold))
                    .multilineTextAlignment(.center)
                    .transition(.opacity)
                
                Text(bodyText)
                    .font(.title3.weight(.regular))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 10)
                    .transition(.opacity)
            }
            .padding(22)
            .frame(maxWidth: 560)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
            .padding(.horizontal, 18)
            
            Spacer()
            
            if pageIndex < 2 {
                Text("Tap anywhere to continue")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(.secondary.opacity(0.7))
                    .padding(.bottom, 18)
            } else {
                Button {
                    onDone()
                } label: {
                    Text("Finish")
                        .font(.headline)
                        .frame(maxWidth: 560)
                        .padding(.vertical, 14)
                }
                .buttonStyle(PrimaryGlassButtonStyle())
                .padding(.horizontal, 18)
                .padding(.bottom, 18)
            }
        }
        .padding(.top, 22)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            if pageIndex < 2 {
                withAnimation(.easeInOut(duration: 0.25)) {
                    pageIndex += 1
                }
            }
        }
        .animation(.easeInOut(duration: 0.25), value: pageIndex)
    }
    
    private var titleText: String {
        if pageIndex == 2 {
            return "A better default"
        } else {
            return "Reflection"
        }
    }
    
    private var bodyText: String {
        if pageIndex == 0 {
            return "Now that you had a peek of how life is for the disabled..."
        } else if pageIndex == 1 {
            return "More than 1.3 billion people worldwide live with some form of disability. That is roughly 1 in 6 people."
        } else {
            return "Support features should be the bare minimum, everyone should have the prviledge to participate in everyday life."
        }
    }
}
