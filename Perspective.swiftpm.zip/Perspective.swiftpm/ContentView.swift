import SwiftUI

struct ContentView: View {
    @StateObject private var model = AppModel()
    @State private var hasStarted = false
    @State private var showReflection = false
    
    var body: some View {
        ZStack {
            TranquilBackground()
                .ignoresSafeArea()
            
            content
                .animation(.easeInOut(duration: 0.35), value: hasStarted)
                .animation(.easeInOut(duration: 0.35), value: showReflection)
                .animation(.easeInOut(duration: 0.35), value: model.currentLens)
        }
    }
    
    @ViewBuilder
    private var content: some View {
        if !hasStarted {
            StartView(hasStarted: $hasStarted)
                .transition(.opacity)
            
        } else if showReflection {
            ReflectionView(model: model) {
                showReflection = false
            }
            .transition(.opacity)
            
        } else if model.currentLens == nil {
            HomeView(model: model) {
                showReflection = true
            }
            .transition(.opacity)
            
        } else {
            ScenarioView()
                .environmentObject(model)
                .transition(.opacity)
        }
    }
}
