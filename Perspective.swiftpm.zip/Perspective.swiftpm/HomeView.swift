import SwiftUI

struct HomeView: View {
    @ObservedObject var model: AppModel
    var onReflection: () -> Void = {}
    
    private var allLensesCompleted: Bool {
        model.completedLenses.count == LensType.allCases.count
    }
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {
                header
                
                VStack(spacing: 12) {
                    ForEach(Array(LensType.allCases), id: \.self) { lens in
                        lensRow(for: lens)
                    }
                }
                
                if allLensesCompleted {
                    Button {
                        onReflection()
                    } label: {
                        HStack {
                            Text("Reflection")
                                .font(.headline)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                        .padding(18)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 6)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 22)
        }
    }
    
    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Perspective")
                .font(.system(.largeTitle, design: .rounded).weight(.semibold))
            
            Text("Choose a perspective to experience friction first, then replay with supports enabled.")
                .font(.body)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(.white.opacity(0.12), lineWidth: 1)
        )
    }
    
    private func lensRow(for lens: LensType) -> some View {
        Button {
            model.currentLens = lens
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(.ultraThinMaterial)
                        .frame(width: 46, height: 46)
                        .overlay(
                            Circle()
                                .strokeBorder(.white.opacity(0.14), lineWidth: 1)
                        )
                    
                    Image(systemName: lens.icon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.primary)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(lens.rawValue)
                        .font(.headline)
                        .foregroundStyle(.primary)
                    
                    Text(model.completedLenses.contains(lens) ? "Explored" : "Not yet explored")
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                if model.completedLenses.contains(lens) {
                    Image(systemName: "checkmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                        .padding(.trailing, 2)
                } else {
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(.white.opacity(0.12), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}
