import SwiftUI

// MARK: - Tranquil Background

struct TranquilBackground: View {
    var body: some View {
        ZStack {
            Color(.systemBackground)
            
            // Soft liquid color pools (very subtle)
            RadialGradient(
                colors: [
                    Color.blue.opacity(0.12),
                    Color.clear
                ],
                center: .topLeading,
                startRadius: 50,
                endRadius: 500
            )
            
            RadialGradient(
                colors: [
                    Color.purple.opacity(0.10),
                    Color.clear
                ],
                center: .bottomTrailing,
                startRadius: 50,
                endRadius: 500
            )
        }
        .ignoresSafeArea()
    }
}

// MARK: - Glass Surface Modifier

struct GlassSurface: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.25), lineWidth: 0.8)
            )
            .shadow(color: Color.black.opacity(0.08), radius: 20, x: 0, y: 10)
    }
}

extension View {
    func glassSurface() -> some View {
        modifier(GlassSurface())
    }
}

// MARK: - Primary Apple-Style Button

struct PrimaryGlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(.ultraThinMaterial)
                    
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.white.opacity(0.3), lineWidth: 0.8)
                }
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
            .shadow(color: Color.black.opacity(0.06), radius: 12, x: 0, y: 6)
    }
}
