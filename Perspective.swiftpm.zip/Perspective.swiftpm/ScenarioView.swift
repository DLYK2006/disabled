import SwiftUI

struct ScenarioView: View {
    @EnvironmentObject var model: AppModel
    
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Color.clear.ignoresSafeArea()
                
                if model.showEducationalInterstitial {
                    interstitialView
                        .padding(.top, max(16, geo.safeAreaInsets.top + 8))
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                } else {
                    VStack(spacing: 14) {
                        header
                        
                        stageBody
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .fill(.ultraThinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
                            )
                    }
                    .padding(.top, max(16, geo.safeAreaInsets.top + 8))
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
                
                if let feedback = model.stageFeedback {
                    feedbackOverlay(feedback)
                }
            }
            .onAppear {
                if model.currentLens != .motorImpairment {
                    model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                }
                model.beginLensSessionIfNeeded()
            }
            .onChange(of: geo.size) { _ in
                if model.currentLens != .motorImpairment {
                    model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                }
                model.configureCurrentStage()
            }
            .onChange(of: model.currentStepIndex) { _ in
                if model.currentLens != .motorImpairment {
                    model.setupStage(in: geo.safeAreaInsetsAdjustedFrame.size)
                }
                model.configureCurrentStage()
            }
            .onReceive(timer) { _ in
                model.updateMotorTimeout()
            }
        }
    }
    
    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Button {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        model.stageFeedback = nil
                        model.showEducationalInterstitial = false
                        model.currentLens = nil
                    }
                } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .frame(width: 38, height: 38)
                        .background(.ultraThinMaterial, in: Circle())
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(0.12), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .disabled(model.stageFeedback != nil)
                .opacity(model.stageFeedback != nil ? 0.4 : 1)
                .accessibilityLabel("Exit")
                
                Label(model.currentScenario.name, systemImage: headerIcon)
                    .font(.system(.title2, design: .rounded).weight(.semibold))
                    .foregroundStyle(.primary)
                
                Spacer()
                
                if model.isCurrentLensCompleted {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.green)
                        .accessibilityLabel("Lens completed")
                }
            }
            
            if model.shouldShowProgress {
                ProgressView(value: model.progress)
                    .tint(.blue)
                
                Text(model.stepLabel)
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(.secondary)
            }
            
            Text(model.currentScenario.steps[model.currentStepIndex].title)
                .font(.system(.headline, design: .rounded))
                .foregroundStyle(.primary)
            
            Text(model.currentScenario.steps[model.currentStepIndex].description)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.12), lineWidth: 1)
        )
    }
    
    private var headerIcon: String {
        switch model.currentLens {
        case .blindness:
            return "eye.slash.fill"
        case .motorImpairment:
            return "hand.raised.slash.fill"
        case .neurodiversity:
            return "brain.head.profile"
        case .none:
            return "circle"
        }
    }
    
    @ViewBuilder
    private var stageBody: some View {
        switch model.currentLens {
        case .blindness:
            blindnessStage
        case .motorImpairment:
            motorStage
        case .neurodiversity:
            neurodiversityStage
        case .none:
            EmptyView()
        }
    }
    
    private var blindnessStage: some View {
        GeometryReader { localGeo in
            ZStack {
                Button {
                    model.triggerBlindnessAction()
                } label: {
                    Text(model.currentScenario.steps[model.currentStepIndex].actionLabelOn)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(height: model.supportsEnabled ? 42 : 34)
                        .frame(minWidth: model.supportsEnabled ? 140 : 110)
                        .background(model.isButtonRevealed ? Color.green : Color.clear, in: Capsule())
                }
                .position(model.realButtonPosition)
                .disabled(!model.isButtonRevealed)
                .opacity(model.isButtonRevealed ? 1 : 0.01)
                .shadow(
                    color: .green.opacity(
                        model.isButtonRevealed
                        ? (model.supportsEnabled ? (0.25 + (0.35 * model.blindnessPulseOpacity)) : 0.65)
                        : 0
                    ),
                    radius: model.supportsEnabled ? 6 : 10,
                    x: 0,
                    y: 0
                )
                
                if !model.supportsEnabled {
                    ForEach(Array(model.blindnessDecoyPositions.enumerated()), id: \.offset) { _, decoyPosition in
                        Button {
                            // distraction only
                        } label: {
                            Capsule()
                                .fill(Color.red.opacity(0.88))
                                .frame(width: 76, height: 28)
                                .overlay(
                                    Capsule()
                                        .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
                                )
                        }
                        .position(decoyPosition)
                        .buttonStyle(.plain)
                    }
                }
                
                if !model.isButtonRevealed {
                    Rectangle()
                        .fill(Color.black.opacity(model.supportsEnabled ? 0.92 : 1.0))
                        .mask(
                            ZStack {
                                Rectangle().fill(Color.white)
                                if let flashlightLocation = model.flashlightPoint {
                                    Circle()
                                        .fill(
                                            RadialGradient(
                                                colors: [
                                                    .black,
                                                    .black.opacity(model.supportsEnabled ? 0.98 : 0.45),
                                                    .clear
                                                ],
                                                center: .center,
                                                startRadius: 1,
                                                endRadius: model.flashlightRadius
                                            )
                                        )
                                        .frame(width: model.flashlightRadius * 2, height: model.flashlightRadius * 2)
                                        .position(flashlightLocation)
                                        .blur(radius: model.supportsEnabled ? 0.25 : 1.2)
                                        .blendMode(.destinationOut)
                                }
                            }
                                .compositingGroup()
                        )
                        .allowsHitTesting(false)
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged { value in
                        if model.flashlightPoint == nil {
                            model.beginBlindnessFlashlight(at: value.location)
                        } else {
                            model.moveBlindnessFlashlight(to: value.location)
                        }
                    }
                    .onEnded { _ in
                        model.endBlindnessFlashlight()
                    }
            )
            .onAppear {
                model.setupStage(in: localGeo.size)
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { newSize in
                model.setupStage(in: newSize)
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 0.8)
        )
        .padding(12)
    }
    
    private var motorStage: some View {
        GeometryReader { localGeo in
            ZStack {
                Color.clear
                
                Button {
                    if model.supportsEnabled {
                        model.triggerMotorTap()
                    }
                } label: {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(Color.blue)
                        .frame(width: model.supportsEnabled ? 220 : 15, height: model.supportsEnabled ? 60 : 15)
                        .shadow(color: .black.opacity(0.10), radius: 10, x: 0, y: 6)
                }
                .position(model.motorButtonPosition)
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.6)
                        .onEnded { _ in
                            if !model.supportsEnabled {
                                model.triggerMotorOffLongPress()
                            }
                        }
                )
                .simultaneousGesture(
                    TapGesture(count: 2)
                        .onEnded {
                            if !model.supportsEnabled {
                                model.triggerMotorOffDoubleTap()
                            }
                        }
                )
            }
            .onAppear {
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
            .onChange(of: localGeo.size) { _ in
                model.setStageBounds(localGeo.frame(in: .local))
                model.configureCurrentStage()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Color.white.opacity(0.10), lineWidth: 0.8)
        )
        .overlay(alignment: .bottomLeading) {
            Text(model.supportsEnabled ? "Tap the large button" : "Use long press or double tap quickly")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(12)
        }
        .padding(12)
    }
    
    private var neurodiversityStage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text(model.supportsEnabled ? "Cognitive Load: Low" : "Cognitive Load: High")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(model.supportsEnabled ? .green : .orange)
                
                if model.supportsEnabled {
                    Text(cognitiveStageContent.heading)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(cognitiveStageContent.structuredBullets, id: \.self) { bullet in
                            Text("• \(bullet)")
                        }
                    }
                    .font(.body)
                } else {
                    Text(cognitiveStageContent.unstructuredParagraph)
                        .font(.body)
                }
                
                VStack(spacing: 10) {
                    ForEach(Array(cognitiveStageContent.choices.enumerated()), id: \.offset) { _, choice in
                        if model.supportsEnabled {
                            Button {
                                model.triggerCognitiveChoice(isCorrect: choice.isCorrect)
                            } label: {
                                Text(choice.label)
                            }
                            .buttonStyle(PrimaryGlassButtonStyle())
                        } else {
                            Button {
                                model.triggerCognitiveChoice(isCorrect: choice.isCorrect)
                            } label: {
                                HStack {
                                    Text(choice.label)
                                        .font(.headline)
                                        .foregroundStyle(.primary)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundStyle(.secondary)
                                }
                                .padding(.vertical, 12)
                                .padding(.horizontal, 14)
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
        }
        .padding(12)
    }
    
    private var interstitialView: some View {
        ZStack {
            Color.clear.ignoresSafeArea()
            
            VStack(spacing: 18) {
                Label("Reflection", systemImage: "lightbulb.fill")
                    .font(.system(.headline, design: .rounded).weight(.semibold))
                    .foregroundStyle(.secondary)
                
                Text("Notice that frustration? Lets see how different it would be if the campus were to implement disability support features.")
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Button("Start Simulation with Supports") {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        model.enableSupportsFromInterstitial()
                    }
                }
                .buttonStyle(PrimaryGlassButtonStyle())
            }
            .padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
            )
            .padding(24)
        }
    }
    
    private func feedbackOverlay(_ feedback: StageFeedback) -> some View {
        ZStack {
            Color.black.opacity(0.25).ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Label("Stage Reflection", systemImage: "checkmark.seal.fill")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                
                Text(feedback.barrier)
                    .font(.subheadline)
                
                Text(feedback.fix)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                
                Button("Continue") {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        model.advanceFromFeedback()
                    }
                }
                .buttonStyle(PrimaryGlassButtonStyle())
            }
            .padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
            )
            .padding(24)
        }
        .transition(.opacity)
    }
    
    private var cognitiveStageContent: (heading: String, unstructuredParagraph: String, structuredBullets: [String], choices: [(label: String, isCorrect: Bool)]) {
        switch model.currentStepIndex {
        case 0:
            return (
                heading: "Entrance Access",
                unstructuredParagraph: "Before you try to enter, take a second to confirm which entry method is active today because the usual flow changes depending on whether the access keypad is currently being used for student check in or whether you are supposed to pause near the service area until someone verifies your name, and if you do not see a clear sign immediately you should avoid forcing the main door and instead either wait briefly where deliveries are typically staged or use the side entry control that sometimes confirms access faster, but only after you are sure you are not bypassing the hold instruction that applies when staffing is limited.",
                structuredBullets: [
                    "Use the side door keypad for building entry.",
                    "Wait for confirmation, then proceed inside.",
                    "Ignore temporary notices that do not change this step."
                ],
                choices: [
                    ("Use side door keypad", true),
                    ("Wait by loading dock", false)
                ]
            )
        case 1:
            return (
                heading: "Elevator Routing",
                unstructuredParagraph: "When you reach the elevator area, the directions start to overlap because one sign points toward check in on a lower level while another points toward the main lab corridor upstairs, and the message you got earlier mentions equipment pickup in a way that makes Floor 2 sound relevant, but the repeated references to the lab corridor and the robotics space keep pulling your attention to the higher floor. You can tell Floor 4 is probably the right choice for getting to the lab without extra looping, yet the mixed wording and conflicting cues make you hesitate because it is not completely clear whether you are expected to stop somewhere first or go straight to the lab corridor.",
                structuredBullets: [
                    "Go to the elevator panel.",
                    "Select Floor 4.",
                    "Continue to the lab corridor after arrival."
                ],
                choices: [
                    ("Press Floor 4", true),
                    ("Press Floor 2", false)
                ]
            )
        default:
            return (
                heading: "Lab Door Entry",
                unstructuredParagraph: "At the lab door, the process can feel like it depends on timing and small cues because sometimes the reader takes a moment to register and sometimes the handle will move slightly even when it is not fully unlocked, so if you are unsure whether the badge tap registered you might try the handle quickly to see if it gives, but the safer sequence is to make sure the reader actually completes the scan first since repeated pulling can happen before the authorization finishes, and if you do not notice the confirmation right away you should pause, re align, and try again in the way that produces the green indicator rather than relying on the handle movement to tell you the status.",
                structuredBullets: [
                    "Tap your badge at the reader.",
                    "Hold until the indicator turns green.",
                    "Open the door after confirmation."
                ],
                choices: [
                    ("Tap badge and hold", true),
                    ("Pull handle twice", false)
                ]
            )
        }
    }
}

private extension GeometryProxy {
    var safeAreaInsetsAdjustedFrame: CGRect {
        CGRect(
            x: safeAreaInsets.leading,
            y: safeAreaInsets.top,
            width: size.width - safeAreaInsets.leading - safeAreaInsets.trailing,
            height: size.height - safeAreaInsets.top - safeAreaInsets.bottom
        )
    }
}
